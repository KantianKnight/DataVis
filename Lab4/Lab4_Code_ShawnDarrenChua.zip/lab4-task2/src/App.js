import { useState } from 'react';
import './App.css';

// ScatterPlot Component
function ScatterPlot({ data }) {
  const [threshold, setThreshold] = useState(0);

  return (
    <div className="scatter-plot">
      <div className="scatter-plot-canvas">
        {data.map(point => {
          const isBelowThreshold = point.y < threshold;
          return (
            <div
              key={point.id}
              className={`scatter-point scatter-point-${point.category.toLowerCase()} ${isBelowThreshold ? 'desaturated' : ''}`}
              style={{
                left: `${point.x}%`,
                bottom: `${point.y}%`,
                opacity: isBelowThreshold ? 0.2 : 1
              }}
              title={`(${point.x}, ${point.y}) - ${point.category}`}
            />
          );
        })}
      </div>
      <div className="scatter-controls">
        <div className="control-row">
          <label htmlFor="threshold-slider">
            Threshold: {threshold}
          </label>
          <input
            id="threshold-slider"
            type="range"
            min="0"
            max="100"
            value={threshold}
            onChange={(e) => setThreshold(Number(e.target.value))}
            className="threshold-slider"
          />
        </div>
        <div className="legend">
          <span className="legend-title">Categories:</span>
          <div className="legend-item">
            <span className="legend-color legend-alpha"></span>
            Alpha
          </div>
          <div className="legend-item">
            <span className="legend-color legend-beta"></span>
            Beta
          </div>
          <div className="legend-item">
            <span className="legend-color legend-gamma"></span>
            Gamma
          </div>
        </div>
      </div>
    </div>
  );
}

// Scatter plot data
const scatterData = [
  { id: 1, x: 12, y: 85, category: "Alpha" },
  { id: 2, x: 45, y: 22, category: "Beta" },
  { id: 3, x: 67, y: 90, category: "Alpha" },
  { id: 4, x: 89, y: 45, category: "Gamma" },
  { id: 5, x: 23, y: 12, category: "Beta" },
  { id: 6, x: 56, y: 67, category: "Alpha" },
  { id: 7, x: 91, y: 34, category: "Gamma" },
  { id: 8, x: 15, y: 78, category: "Beta" },
  { id: 9, x: 34, y: 56, category: "Alpha" },
  { id: 10, x: 72, y: 88, category: "Gamma" },
  { id: 11, x: 8, y: 95, category: "Alpha" },
  { id: 12, x: 50, y: 50, category: "Beta" },
  { id: 13, x: 29, y: 41, category: "Gamma" },
  { id: 14, x: 81, y: 19, category: "Alpha" },
  { id: 15, x: 63, y: 72, category: "Beta" },
  { id: 16, x: 95, y: 60, category: "Gamma" },
  { id: 17, x: 41, y: 33, category: "Alpha" },
  { id: 18, x: 19, y: 82, category: "Beta" },
  { id: 19, x: 76, y: 25, category: "Gamma" },
  { id: 20, x: 38, y: 66, category: "Alpha" },
  { id: 21, x: 5, y: 15, category: "Beta" },
  { id: 22, x: 88, y: 92, category: "Gamma" },
  { id: 23, x: 60, y: 48, category: "Alpha" },
  { id: 24, x: 25, y: 75, category: "Beta" },
  { id: 25, x: 48, y: 10, category: "Gamma" },
  { id: 26, x: 98, y: 55, category: "Alpha" },
  { id: 27, x: 31, y: 89, category: "Beta" },
  { id: 28, x: 69, y: 38, category: "Gamma" },
  { id: 29, x: 14, y: 28, category: "Alpha" },
  { id: 30, x: 53, y: 80, category: "Beta" }
];

function App() {
  return (
    <div className="app">

      {/* Header */}
      <header className="app-header">
        <span className="header-title">Header Title</span>
        <span className="header-tagline">Header Tagline</span>
      </header>

      {/* Main 3-column area */}
      <div className="main">

        {/* Left sidebar */}
        <aside className="sidebar">
          <div className="box box-description">
            <span className="label">a</span>
            Description &amp; Info
          </div>
          <div className="box box-charts">
            <span className="label">b</span>
            Bar Charts
          </div>
          <div className="box box-controls">
            <span className="label">c</span>
            Slider and Button Controls
          </div>
        </aside>

        {/* Centre column */}
        <div className="centre">

          {/* Top row: two projectors */}
          <div className="projectors">
            <div className="box box-projector">
              <span className="label">d1</span>
              <ScatterPlot data={scatterData} />
            </div>
            <div className="box box-projector">
              <span className="label">d2</span>
              Data Projector #2
            </div>
          </div>

          {/* Bottom: instance explainer */}
          <div className="box box-explainer">
            <span className="label">e</span>
            Explanation and Visuals
          </div>
        </div>

        {/* Right panel */}
        <aside className="confidence">
          <div className="box box-confidence">
            <span className="label">f</span>
            Bar Charts
          </div>
        </aside>

      </div>

      {/* Footer */}
      <footer className="app-footer">
        <div className="box box-footer">
          <span className="label">g</span>
          Footer
        </div>
      </footer>

    </div>
  );
}

export default App;
